.onAttach <- function(libname, pkgname)
{
  ##check 'gets' version:
  requiredVersion <- package_version("0.39")
  getsVersion <- packageVersion("gets")
  versionOK <- getsVersion >= requiredVersion
  if( !versionOK ){
    warning("package 'getslmem' requires version 0.39 or later of package 'gets'")
  }

} #close .onAttach
