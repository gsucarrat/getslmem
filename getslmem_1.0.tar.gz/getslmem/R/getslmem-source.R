###########################################################
## This file contains the source of the lmem() functions.
##
## First created 20 July 2024, Zaragoza.
##
## Contents:
##
## TO DO: lmemSim()
## lmem()
## coef.lmem()         #extraction functions
## fitted.lmem()       #(all are S3 methods)
## gets.lmem()
## logLik.lmem()
## model.matrix.lmem()
## nobs.lmem()
## plot.lmem()
## predict.lmem()
## print.lmem()
## residuals.lmem()
## summary.lmem()
## toLatex.lmem()
## vcov.lmem()
##
###########################################################

###########################################################
## The function lmemSim() simulates from a log-MEM-X model
###########################################################

## TO DO: lmemSim <- function(n, ...)


###########################################################
## lmem() estimate a log-MEM-X model
###########################################################

lmem <- function(y, intercept=TRUE, ar=NULL, log.ewma=NULL, xreg=NULL,
  zero.adj=NULL, vcov.type=c("robust", "hac"), qstat.options=NULL,
  user.estimator=NULL, tol=1e-07, singular.ok=TRUE, plot=NULL)
{
  ## contents:
  ##
  ## 1 initiate
  ## 2 create aux list
  ## 3 estimation
  ## 4 prepare result
  ## 5 finalise and return result


  ##-----------------------------------
  ## 1 initiate
  ##-----------------------------------

  ##record call:
  sysCall <- sys.call()

  ##check 'gets' version:
  requiredVersion <- package_version("0.39")
  getsVersion <- packageVersion("gets")
  versionOK <- getsVersion >= requiredVersion
  if( !versionOK ){
    stop("package 'getslmem' requires version 0.39 or later of package 'gets'")
  }
  
  ##check argument(s):
  if( !intercept==TRUE ){ stop("argument 'intercept' must be TRUE") }
  
  ##regressand, regressors:
  y.name <- deparse(substitute(y))
  e <- sqrt(y) #'as if' return 
  tmp <- regressorsVariance(e, vc=TRUE, arch=ar, log.ewma=log.ewma,
    vxreg=xreg, prefix="", arch.prefix="ar", zero.adj=zero.adj,
    return.regressand=TRUE, return.as.zoo=TRUE, na.trim=TRUE, na.omit=FALSE)
  colnames(tmp)[1:2] <- c("logy", "intercept")    
  y <- as.zoo(y)
  y <- zoo( as.vector(coredata(y)), order.by=index(y)) #convert to vector (recall: regressorsVariance() does not accept NCOL(y) > 1)
  y <- window(y, start=index(tmp)[1], end=index(tmp)[NROW(tmp)]) 

  ##singularity ok?:
  if( singular.ok && NCOL(tmp)>2 ){
    tmpx <-
      colnames(dropvar(tmp[,-1], tol=tol, LAPACK=FALSE, silent=TRUE))
    droppedXs <- which( (colnames(tmp[,-1]) %in% tmpx)==FALSE )
    if( length(droppedXs)>0 ){
      droppedXsNames <- colnames(tmp)[c(1+droppedXs)]
      tmp <- tmp[,-c(1+droppedXs)]
      warning(
        "Regressor(s) removed due to singularity:\n",
        paste(" ", droppedXsNames)
      )            
    } #end if( length(droppedXs)>0 )
  } #end if( singular.ok )

  ##determine vcov type:
  types <- c("robust", "hac")
  whichType <- charmatch(vcov.type[1], types)
  vcov.type <- types[ whichType ]

  ##determine qstat.options:
  if( is.null(qstat.options) ){
    if( is.null(ar) ){ ar.lag <- 1 }else{ ar.lag <- max(ar)+1 }
    qstat.options <- ar.lag
  }

  
  ##-----------------------------------
  ## 2 create aux list
  ##-----------------------------------

  ##aux: auxiliary list, also to be used by getsv
  aux <- list()
  #add in the future?: aux$y.original <- y.original
  aux$e <- coredata(sqrt(y)) #sqrt(y) of original series y
  aux$y <- coredata(y)
  aux$y.index <- index(y)
  aux$y.name <- y.name #recorded above, in the beginning
  aux$logy <- coredata(tmp[,1])
  aux$vX <- cbind(coredata(tmp[,-1]))
  aux$vXnames <- colnames(tmp)[-1]
  aux$zero.adj <- zero.adj
  aux$qstat.options <- qstat.options
  aux$tol <- tol


  ##-----------------------------------
  ## 3 estimation
  ##-----------------------------------

  ## default estimator:
  if( is.null(user.estimator) ){

    out <- larchEstfun(aux$logy, aux$vX, aux$e, vcov.type=vcov.type,
      tol=tol)
    names(out$coefficients) <- aux$vXnames
    colnames(out$vcov) <- aux$vXnames
    rownames(out$vcov) <- aux$vXnames
    where <- which( names(out) == "fit" )
    names(out)[ where ] <- "fitted" #rename
    out$residuals <- out$residuals^2
    aux <- c(aux,out)

  }
  
  ## user-defined estimator:
  if( !is.null(user.estimator) ){

    ##make user-estimator argument:
    if( is.null(user.estimator$envir) ){
      user.estimator$envir <- .GlobalEnv
    }
    userEstArg <- user.estimator
    userEstArg$name <- NULL
    userEstArg$envir <- NULL
    if( length(userEstArg)==0 ){ userEstArg <- NULL }
    
    ##user-defined estimator:
    if( is.null(user.estimator$envir) ){
      out <- do.call(user.estimator$name,
        c(list(aux$logy, aux$vX, aux$e), userEstArg))
    }else{
      out <- do.call(user.estimator$name,
        c(list(aux$logy, aux$vX, aux$e), userEstArg), envir=user.estimator$envir)
    }

    ##add out to aux:
    aux <- c(aux,out)
    
  }

  ##build 'results' data frame:
  s.e. <- sqrt(as.vector(diag(aux$vcov)))
  t.stat <- aux$coefficients/s.e.
  p.val <- pt(abs(t.stat), aux$k, lower.tail=FALSE)*2
  aux$results <-
    as.data.frame(cbind(aux$coefficients, s.e., t.stat, p.val))
  colnames(aux$results) <- c("coef", "std.error", "t-stat", "p-value")
  rownames(aux$results) <- aux$vXnames
  names(aux$coefficients) <- aux$vXnames


  ##-----------------------------------
  ## 4 prepare result
  ##-----------------------------------

  ##diagnostics:
  if( "residuals" %in% names(aux) ){
    ar.LjungBarg <- c(qstat.options[1],0)
    arch.LjungBarg <- NULL
    normality.JarqueBarg <- NULL
  }else{
    ar.LjungBarg <- NULL
    arch.LjungBarg <- NULL
    normality.JarqueBarg <- NULL
  }
  aux$diagnostics <- diagnostics(aux,
    ar.LjungB=ar.LjungBarg, arch.LjungB=arch.LjungBarg,
    normality.JarqueB=normality.JarqueBarg,
    user.fun=NULL, verbose=TRUE)

  ##add zoo-indices:
  if( "fitted" %in% names(aux) ){
    aux$fitted <- zoo(aux$fitted, order.by=aux$y.index)
  }
  if( "residuals" %in% names(aux) ){
    aux$residuals <- zoo(aux$residuals, order.by=aux$y.index)
  }


  ##-----------------------------------
  ## 5 finalise and return result
  ##-----------------------------------

  versionTxt <- paste0("gets ", getsVersion, " under ",
    version$version.string)
  aux <-
    c(list(call=sysCall, date=date(), version=versionTxt), aux)
  class(aux) <- "lmem"

  ##plot?:
  if( is.null(plot) ){
    plot <- getOption("plot")
    if( is.null(plot) ){ plot <- FALSE }
  }
  if( plot ){ plot.lmem(aux) }

  ##return result:
  return(aux)

} #close lmem() function


##########################################################
## coef.lmem()
###########################################################

coef.lmem <- function(object, ...){ return(object$coefficients) }


###########################################################
## fitted.lmem()
###########################################################

fitted.lmem <- function(object, ...){ return(object$fitted) }


###########################################################
## gets.lmem() GETS-modelling of object of class "lmem"
###########################################################

gets.lmem <- function(x, t.pval=0.05, wald.pval=t.pval, do.pet=TRUE,
  ar.LjungB=NULL, user.diagnostics=NULL,
  info.method=c("sc", "aic", "aicc", "hq"), gof.function=NULL,
  gof.method=NULL, keep=c(1), include.gum=FALSE, include.1cut=FALSE,
  include.empty=FALSE, max.paths=NULL, tol=1e-07, turbo=FALSE,
  print.searchinfo=TRUE, plot=NULL, alarm=FALSE, ...)
{
  ## contents:
  ## 1 arguments
  ## 2 gets modelling
  ## 3 estimate specific
  ## 4 result
  
  ##------------------
  ## 1 arguments
  ##------------------

  ##diagnostics: ar argument
  if( !is.null(ar.LjungB) && is.vector(ar.LjungB, mode="double") ){
      ar.LjungB <- list(lag=ar.LjungB[1], pval=ar.LjungB[2])
  }
  if( !is.null(ar.LjungB) && is.null(ar.LjungB$lag) ){
    ar.LjungB$lag <- x$qstat.options[1]
  }
  ar.LjungB <- c(ar.LjungB$lag[1], ar.LjungB$pval[1])
  ##(NULL if ar.LjungB is NULL)

  ##gof arguments:
  if( is.null(gof.function) ){
    ##determine info method:
    infoTypes <- c("sc","aic","aicc","hq")
    whichMethod <- charmatch(info.method[1], infoTypes)
    info.method <- infoTypes[ whichMethod ]
    ##make gof arguments:
    gof.function <- list(name="infocrit", method=info.method)
    gof.method <- "min"
  }

  ##------------------
  ## 2 gets modelling
  ##------------------

  ##out list:
  out <- list()
  out$time.started <- date()
  out$time.finished <- NA
  out$gum.call <- x$call
  mX <- x$vX
  colnames(mX) <- x$vXnames
  if( !(1 %in% keep) ){
    keep <- union(1,keep)
    warning("Regressor 1 included into 'keep'")
  }

  ##add gum results and diagnostics to out:
  tmp <- matrix(0, NROW(x$results), 2)
  colnames(tmp) <- c("reg.no.", "keep")
  tmp[,1] <- 1:NROW(tmp) #fill reg.no. column
  tmp[keep,2] <- 1 #fill keep column
  out$gum.results <- cbind(tmp, x$results)
  out$gum.diagnostics <- x$diagnostics

  ##print start model (gum) info:
  if( print.searchinfo ){
    if( !is.null(out$gum.results) ){
      cat("\n")
      cat("Start model:\n")
      cat("\n")
      printCoefmat(out$gum.results, cs.ind=c(3,4), tst.ind=c(5),
        signif.stars=TRUE, P.values=TRUE)
    }
    if( !is.null(out$gum.diagnostics) ){
      cat("\n")
      cat("Diagnostics:\n")
      cat("\n")
      printCoefmat(out$gum.diagnostics, tst.ind=2, signif.stars=TRUE)
      cat("\n")
    }
  } #end if( print.searchinfo )

  ##do the gets:
  est <- getsFun(x$logy, mX, user.estimator=list(name="larchEstfun",
    e=x$e, vcov.type=x$vcov.type, tol=x$tol),
    gum.result=NULL, t.pval=t.pval, wald.pval=wald.pval, do.pet=do.pet,
    ar.LjungB=ar.LjungB, arch.LjungB=NULL,
    normality.JarqueB=NULL, user.diagnostics=user.diagnostics,
    gof.function=gof.function, gof.method=gof.method, keep=keep,
    include.gum=include.gum, include.1cut=include.1cut,
    include.empty=include.empty, max.paths=max.paths, turbo=turbo,
    tol=tol, max.regs=NULL, print.searchinfo=print.searchinfo,
    alarm=alarm)
  est$time.started <- NULL
  est$time.finished <- NULL
  est$call <- NULL
  out <- c(out, est)

  ##print paths, terminals and retained regressors:
  if( print.searchinfo && !is.null(est$terminals.results) ){

    ##paths:
    if( length(est$paths)>0 ){
      cat("\n")
      for(i in 1:length(est$paths)){
        txt <- paste0(est$paths[[i]], collapse=" ")
        txt <- paste0("  Path ", i, ": ", txt)    
        cat(txt, "\n")
      }
    }

    ##print terminals:
    cat("\n")
    cat("Terminal models:\n")
    cat("\n")
    print(est$terminals.results)    

    ##retained regressors:
    cat("\n")
    cat("Retained regressors (final model):\n")
    if( length(est$specific.spec)==0 ){
      cat("  none\n")
    }else{
      cat(paste0("  ", x$vXnames[as.numeric(est$specific.spec)]), "\n")
    }
    
  } #end   if( print.searchinfo && !is.null(est$terminals.results) )

  ##messages:
  if( print.searchinfo && !is.null(est$messages) ){
    message("\n", appendLF=FALSE)
    message("Messages:", appendLF=TRUE)
    message("\n", appendLF=FALSE)
    message(est$messages)
  }

  ##---------------------
  ## 3 estimate specific
  ##---------------------

  ##if there are no terminals, then use the gum as specific:
  if( is.null(est$terminals.results) ){
    out$messages <- paste0(out$messages,
      "- No terminal models, so the final model equals the GUM")
    out <- c(out,x)
  }  
  
  ##if there are terminals, then estimate specific:
  if( !is.null(est$terminals.results) ){

    ## prepare estimation:
    y <- zoo(cbind(x$y), order.by=x$y.index)
    colnames(y) <- "y"
    specificadj <- setdiff(out$specific.spec, 1)
    if( length(specificadj)==0 ){
      vXadj <- NULL
    }else{
      vXadj <- cbind(x$vX[,specificadj])
      colnames(vXadj) <- x$vXnames[specificadj]
      vXadj <- zoo(vXadj, order.by=x$y.index)
    }
    if( is.null(ar.LjungB) ){ ar.LjungB <- x$qstat.options[1] }
  
    ## estimate specific model:
    est <- lmem(y, intercept=TRUE, xreg=vXadj, zero.adj=x$zero.adj,
      vcov.type=x$vcov.type, qstat.options=ar.LjungB[1], tol=x$tol,
      singular.ok=FALSE, plot=FALSE)
      
    ## delete, rename and change various stuff:
    est$call <- NULL
    est$date <- NULL
    est$y.name <- x$y.name
    est <- unclass(est)
  
    ##build new call (needed for predict.lmem()):
    newCall <- x$call
    coefNames <- names(coef(est))
    indxCounter <- 1 #needed for xreg
      
    ##ar argument for new call:
    gumTerms <- eval(x$call$ar)
    gumNames <- paste0("ar", gumTerms)
    whichRetained <- which( gumNames %in% coefNames )
    if( length(whichRetained)==0 ){
      newCall$ar <- NULL
    }else{
      newCall$ar <- gumTerms[ whichRetained ]
      indxCounter <- indxCounter + length(whichRetained)
    }
      
    ##log.ewma argument for new call:
    gumTerms <- eval(x$call$log.ewma)
    gumNames <- paste0("logEqWMA(", gumTerms, ")")
    whichRetained <- which( gumNames %in% coefNames )
    if( length(whichRetained)==0 ){
      newCall$log.ewma <- NULL
    }else{
      newCall$log.ewma <- gumTerms[ whichRetained ]
      indxCounter <- indxCounter + length(whichRetained)
    }

    ##xreg argument for new call:
    whichRetainedCoefs <- coefNames[ -c(1:indxCounter) ]
    if( length(whichRetainedCoefs)==0 ){
      newCall$xreg <- NULL
    }else{
      whichRetained <- which( est$vXnames %in% whichRetainedCoefs )
      newCall$xreg <- est$vXnames[whichRetained] 
  #more correct, but predict.larch() only needs that vxreg is not NULL:
  #    vxreg <- cbind( est$vX[, whichRetained ] )
  #    colnames(vxreg) <- est$vXnames[whichRetained] 
  #    newCall$vxreg <- vxreg
    }              
  
    ##add new call to 'est', merge with 'out':
    est <- c(list(call=newCall), est)
    out <- c(out,est)

  } #close if( !is.null(est$terminals.results) )


  ##------------------
  ## 4 result
  ##------------------

  out$time.finished <- date()
  out <- c(list(date=out$time.finished), out)
  class(out) <- "lmem"
  if(alarm){ alarm() }
  if( is.null(plot) ){
    plot <- getOption("plot")
    if( is.null(plot) ){ plot <- FALSE }
  }
  if(plot){ plot.lmem(out) }
  return(out)
  
} #close gets.lmem() function


###########################################################
## logLik.lmem()
###########################################################

logLik.lmem <- function(object, ...){ return(object$logl) }


###########################################################
## hist.lmem(): make and plot histogram of residuals
###########################################################

hist.lmem <- function(x, breaks=NULL, plot=TRUE, return=TRUE, ...)
{
  resids <- coredata(residuals.lmem(x))
  breaksArg <- NULL
  if( is.null(breaks) ){
    breaksArg <- round(length(resids)^(5/9))
  }
  result <- hist(resids, breaks=breaksArg, main="Histogram of residuals",
    xlab="Residuals", plot=plot, ...)
  if( return ){
    return(result)
  }
} #close hist.lmem()


###########################################################
## model.matrix.lmem()
###########################################################

model.matrix.lmem <- function(object, response=FALSE,
  as.zoo=TRUE, ...)
{
  result <- NULL
  result <- object$vX
  colnames(result) <- object$vXnames
  if( response==TRUE ){
    logy <- cbind(object$logy)
    colnames(logy) <- "logy"
    result <- cbind(logy,result)
  }
  if( as.zoo==TRUE ){ result <- zoo(result, order.by=object$y.index) }
  return(result)
} #close model.matrix.lmem()


###########################################################
## nobs.lmem()
###########################################################

nobs.lmem <- function(object, ...){ return(object$n) }


###########################################################
## plot.lmem() plot the estimation result
###########################################################

plot.lmem <- function(x, col=c("red","blue"), lty=c("solid","solid"),
  lwd=c(1,1), ...)
{
  ##arguments:
  ##----------
  
  ##col:
  if( length(col)==1 ){
    col=rep(col,2)
  }else if (length(lty)>2){
    print("'col' needs two arguments only, but more provided. First two used.")
    col=col[1:2]
  }

  ##lty:
  if( length(lty)==1 ){
    lty=rep(lty,2)
  }else if (length(lty)>2){
    print("'lty' needs two arguments only, but more provided. First two used.")
    lty=lty[1:2]
  }

  ##lwd:
  if( length(lwd)==1 ){
    lwd=rep(lwd,2)
  }else if (length(lwd)>2){
    print("'lwd' needs two arguments only, but more provided. First two used.")
    lwd=lwd[1:2]
  }

  ##do the plotting:
  ##----------------

  vfitted <- fitted.lmem(x)
  vactual <- zoo(x$y, order.by=x$y.index)
  actual.name <- x$y.name
  residsStd <- residuals.lmem(x)

  ##get current par-values:
  def.par <- par(no.readonly=TRUE)

  ##set new par values for plot:
  par(mfrow=c(2,1))

  #set the plot margins:
  par(mar=c(2,2,0.5,0.5))

  ##plot actual values (e^2):
  minValue <- min(vactual, vfitted, na.rm=TRUE)
  maxValue <- 1.1*max(vactual, vfitted, na.rm=TRUE) #1.1: adds 10% on top
  if( is.regular(vactual) ) {
    plot(vactual, main = "", ylim=range(minValue, maxValue),
      type="l", ylab="", xlab="",col=col[2])
  }else{
    plot(as.Date(index(vactual)), coredata(vactual), main = "",
       ylim=range(minValue,maxValue), type="l", ylab="", xlab="", col=col[2])
  }

  ##plot fitted values:
  if( is.regular(vfitted) ) {
    lines(vfitted, col=col[1])
  } else {
    lines(as.Date(index(vfitted)), coredata(vfitted), col=col[1])
  }
  legend("topleft", lty=lty, lwd=lwd, ncol=2, col=col[c(2,1)],
    legend=c("actual","fitted"), bty="n")

  ##plot standardised residuals:
  minValue <- min(residsStd, na.rm=TRUE)
  maxValue <- 1.1*max(residsStd, na.rm=TRUE) #1.1: adds 10% on top
  if( is.regular(residsStd) ) {
    plot(residsStd, ylim=range(minValue,maxValue), type="h", col=col[1])
  }else{
    plot(as.Date(index(residsStd)), coredata(residsStd), 
      ylim=range(minValue,maxValue), type="h", col=col[1])
  }
  abline(0,0)
  legend("topleft", lty=1, col=col[1],
    legend=c("standardised residuals"), bty="n")

  #return to old par-values:
  par(def.par)

} #close plot.lmem()


############################################################
### predict.lmem() generate predictions
############################################################

predict.lmem <- function(object, n.ahead=12, newxreg=NULL, newindex=NULL,
  n.sim=NULL, innov=NULL, probs=NULL, quantile.type=7, verbose=FALSE, ...)
{
  ## contents:
  ## 1 initialise
  ## 2 prepare terms
  ## 3 simulate innov
  ## 4 prepare prediction
  ## 5 generate predictions
  ## 6 prepare output
  ## 7 newindex
  ## 8 return result

  ##-----------------------
  ## 1 initialise
  ##-----------------------

  ##name of object:
  objectName <- deparse(substitute(object))

  ##check n.ahead:
  if(n.ahead < 1){ stop("n.ahead must be 1 or greater") }

  ##probs argument:
  if( !is.null(probs) ){
    if( any(probs <= 0) || any(probs >= 1) ){
      stop("the values of 'probs' must be between 0 and 1")
    }
    probs <- union(probs,probs) #ensure values are distinct/not repeated
    probs <- probs[order(probs, decreasing=FALSE)] #re-order to increasing
  }
  probsArg <- probs
  
  ##obtain zero.adj value:
  zerosWhere <- which( object$e==0 )
  if( length(zerosWhere)>0 ){
    zero.adj <- exp(object$logy)[ zerosWhere[1] ]
  }else{
    zero.adj <- quantile(object$y, 0.1, na.rm=TRUE) 
  }  


  ##-----------------------
  ## 2 prepare terms
  ##-----------------------

  ##record coef estimates:
  coefs <- as.numeric(coef.lmem(object))
  
  ##vc:
  vconst <- as.numeric(coefs[1])
  
  ##ar:
  arMax <- 0
  arIndx <- 1
  if( "ar" %in% names(object$call) ){
    arEval <- eval(object$call$ar)
    arIndx <- 1:length(arEval) + 1
    arMax <- max(arEval)
    arCoefs <- rep(0,arMax)
    arCoefs[arEval] <- as.numeric(coefs[arIndx])
  }
    
  ##log.ewma:
  logewmaMax <- 0
  logewmaIndx <- max(arIndx)
  if( "log.ewma" %in% names(object$call) ){
    logewmaEval <- eval(object$call$log.ewma)
    if(is.list(logewmaEval)){ logewmaEval <- logewmaEval$length }
    logewmaIndx <- 1:length(logewmaEval) + max(arIndx)
    logewmaMax <- max(logewmaEval)
    logewmaCoefs <- as.numeric(coefs[logewmaIndx])
  }

  ##backcast length:
  backcastMax <- max(arMax,logewmaMax)
  
  ##xreg:
  xreghat <- rep(0, n.ahead + backcastMax)
  if( !is.null(object$call$xreg) ){

    ##check newxreg:
    if( is.null(newxreg) ){ stop("'newxreg' is NULL") }
    if( NROW(newxreg)!=n.ahead ){ stop("NROW(newxreg) must equal n.ahead") }

    ##newmxreg:
    newxreg <- coredata(cbind(as.zoo(newxreg)))
    colnames(newxreg) <- NULL

    ##xreghat (predictions):
    xregIndx <- c(max(logewmaIndx)+1):length(coefs)
    xreghat <-  newxreg %*% coefs[xregIndx]
    xreghat <- c(rep(0,backcastMax),xreghat)

  } #end xreg


  ##-----------------------
  ## 3 simulate innov
  ##-----------------------

  ##determine n.sim value:
  if( is.null(n.sim) && is.null(probs) ){
    if( backcastMax==0 ){
      n.sim <- 1
    }else{ 
      n.sim <- ifelse(n.ahead==1, 1, 5000)
    }
  }
  if( is.null(n.sim) && !is.null(probs) ){ n.sim <- 5000 }
     
  ##simulated innovations:
  mZhat <- NULL

  ##if innov not provided (classic bootstrap):
  if( is.null(innov) ){
    zhat <- coredata(residuals.lmem(object))
    draws <- runif(n.ahead*n.sim, min=0.5+.Machine$double.eps,
                   max=length(zhat)+0.5+.Machine$double.eps)
    draws <- round(draws, digits=0)
    zhat <- zhat[draws]
  }
    
  ##if user-provided innov:
  if( !is.null(innov) ){
    if(length(innov)!=n.ahead*n.sim){ stop("length(innov) must equal n.ahead*n.sim") }
    if( any(innov<0) ){ stop("negative values in 'innov'") }
    zhat <- as.numeric(innov)
  }

  ##matrix of innovations:
  mZhat <- matrix(zhat, n.ahead, n.sim)
  mZhat <- rbind(matrix(NA, backcastMax, NCOL(mZhat)), mZhat) ##modify no. of rows:
  
  
  ##-----------------------
  ## 4 prepare prediction
  ##-----------------------
      
  ##prepare logmu predictions:
  logmuhat <- rep(NA, n.ahead + backcastMax)
  logmuhat.n <- length(logmuhat)
  logmuFit <- log(coredata(fitted.lmem(object)))
  if( backcastMax>0 ){
    logmuhat[1:backcastMax] <- 
      logmuFit[c(length(logmuFit)-backcastMax+1):length(logmuFit)]
  }
  mLogmuHat <- matrix(NA, logmuhat.n, n.sim) #matrix of logmu predictions
  mLogmuHat[,1:NCOL(mLogmuHat)] <- logmuhat  #fill with backcast values
  
  ##prepare logy predictions:
  logyhat <- rep(NA, n.ahead + backcastMax)
  logyhat.n <- length(logyhat)
  logyPast <- object$logy
  if( backcastMax>0 ){
    logyhat[1:backcastMax] <- 
      logyPast[c(length(logyPast)-backcastMax+1):length(logyPast)]
  }
  mLogyHat <- matrix(NA, logyhat.n, n.sim) #matrix of logy predictions
  mLogyHat[,1:NCOL(mLogyHat)] <- logyhat  #fill with backcast values
  
  ##prepare y-predictions:
  yhat <- rep(NA, n.ahead + backcastMax)
  yhat.n <- length(yhat)
  yPast <- object$y
  if( backcastMax>0 ){
    yhat[1:backcastMax] <- 
      yPast[c(length(yPast)-backcastMax+1):length(yPast)]
  }
  mY <- matrix(NA, yhat.n, n.sim) #matrix of y-predictions
  mY[,1:NCOL(mY)] <- yhat  #fill with backcast values
    
  ##prepare log.ewma:
  if( logewmaMax>0 ){
    mLogEwmaHat <- matrix(NA, n.ahead+backcastMax, length(logewmaCoefs))
    colnames(mLogEwmaHat) <- object$vXnames[logewmaIndx]
    mLogEwmaHat[1:backcastMax,] <- object$vX[c(NROW(object$vX)-backcastMax+1):NROW(object$vX),logewmaIndx]
    mLogEwmaHat <- as.matrix(mLogEwmaHat)
  }
  
  
  ##-------------------------
  ## 5 generate predictions
  ##-------------------------
  
  arTerm <- 0
  logewmaTerm <- 0
  
  ##loop over n.sim:
  for(j in 1:NCOL(mLogmuHat)){
  
    ##loop over backcast+n.ahead:
    for(i in c(backcastMax+1):NROW(mLogmuHat) ){
    
      ##compute terms:
      if( arMax>0 ){
        arTerm <- sum( arCoefs*mLogyHat[c(i-1):c(i-arMax),j] )
      }
      if( logewmaMax>0 ){
        for(k in 1:NCOL(mLogEwmaHat)){
          meanTerm <- mean( mY[c(i-logewmaEval[k]):c(i-1),j] )
          meanTerm <- ifelse(meanTerm==0, zero.adj, meanTerm)
          mLogEwmaHat[i,k] <- log(meanTerm)
        }
        logewmaTerm <- sum( coefs[logewmaIndx] * mLogEwmaHat[i,] )
      }

      ##compute predictions:
      mLogmuHat[i,j] <-
        vconst + arTerm + logewmaTerm + xreghat[i]
      mY[i,j] <- exp(mLogmuHat[i,j])*mZhat[i,j]
      if( exp(mLogmuHat[i,j])==Inf ){
        message("message: one or more predictions are Inf")
      }
      mLogyHat[i,j] <- ifelse( mY[i,j]==0, log(zero.adj), log(mY[i,j]) )

    } ##end for(i)

  } ##end for(j)

  ##-----------------------
  ## 6 prepare output
  ##-----------------------

  ##variance predictions:
  mMuHat <- exp( mLogmuHat[c(logmuhat.n-n.ahead+1):logmuhat.n,] )
  if( n.ahead==1 ){ #rbind() needed when n.ahead=1
    mMuHat <- rbind(mMuHat)
  }else{ #cbind() needed in case n.sim=1 (when n.ahead>1)
    mMuHat <- cbind(mMuHat)
  } 
  muhat <- as.vector(rowMeans(mMuHat))
  if( verbose ){ colnames(mMuHat) <- paste0("mMuHat.", seq(1,NCOL(mMuHat))) }
  
  ##innovations:
  mZhat <- rbind(mZhat[c(logmuhat.n-n.ahead+1):logmuhat.n,])
  if( verbose ){ colnames(mZhat) <- paste0("mZhat.", seq(1,n.sim)) }

  ##y:
  mY <- rbind(mY[c(logmuhat.n-n.ahead+1):logmuhat.n,])
  if( verbose ){ colnames(mY) <- paste0("mY.", seq(1,n.sim)) }
  
  ##quantiles of variance predictions:
  mMuQs <- NULL
  if( !is.null(probsArg) ){
    mMuQs <- matrix(NA, n.ahead, length(probsArg))
    for(i in 1:NROW(mMuHat)){
      mMuQs[i,] <- quantile(mMuHat[i,], probs=probsArg, type=quantile.type)
    }
    colnames(mMuQs) <- paste0("q", probsArg)
  }

#FOR THE FUTURE?:
#  ##quantiles of y:
#  mYQs <- NULL
#  if( !is.null(probsArg) ){
#    mYQs <- matrix(NA, n.ahead, length(probsArg))
#    for(i in 1:NROW(mY)){
#      mYQs[i,] <- quantile(mY[i,], probs=probsArg, type=quantile.type)
#    }
#    colnames(mYQs) <- paste0("e", probsArg)
#  }


  ##-----------------------
  ## 7 newindex
  ##-----------------------
  
  ##in-sample:
  yInSample <- zoo(object$y, order.by=object$y.index)

  #newindex user-provided:
  if( !is.null(newindex) ){
    if( n.ahead!=length(newindex) ){
      stop("length(newindex) must equal 'n.ahead'")
    }
    newindexInSample <- any( newindex %in% object$y.index )
  }else{ newindexInSample <- FALSE }

  #in-sample index regular:
  if( is.null(newindex) && is.regular(yInSample, strict=TRUE) ){
    endCycle <- cycle(yInSample)
    endCycle <- as.numeric(endCycle[length(endCycle)])
    endYear <- floor(as.numeric(object$y.index[length(object$y)]))
    yFreq <- frequency(yInSample)
    yhataux <- rep(NA, n.ahead+1)
    yDeltat <- deltat(yInSample)
    if( yDeltat==1 && yFreq==1 ){
      yhataux <- zoo(yhataux, order.by=seq(endYear, endYear+n.ahead, by=1))
      yAsRegular <- FALSE
    }else{
      yhataux <- zooreg(yhataux, start=c(endYear, endCycle), frequency=yFreq)
      yAsRegular <- TRUE
    }
    yhataux <- yhataux[-1]
    newindex <- index(yhataux)
  }

  ##neither user-provided nor regular:
  if( is.null(newindex) ){ newindex <- 1:n.ahead }

  ##add index to results:
  if( !is.null(muhat) ){ muhat <- zoo(muhat, order.by=newindex) }
  if( verbose ){
    if( !is.null(mMuHat) ){ mMuHat <- zoo(mMuHat,  order.by=newindex) }
    if( !is.null(mY) ){ mY <- zoo(mY, order.by=newindex) }
    if( !is.null(mZhat) ){ mZhat <- zoo(mZhat, order.by=newindex) }
    if( !is.null(mMuQs) ){ mMuQs <- zoo(mMuQs, order.by=newindex) }
##FOR THE FUTURE?:
#    if( !is.null(mYQs) ){ mYQs <- zoo(mYQs, order.by=newindex) }
#    if( !is.null(mY2Qs) ){ mY2Qs <- zoo(mY2Qs, order.by=newindex) }
  }

      
  ##-----------------------
  ## 8 return result
  ##-----------------------

  ##return variance predictions only:
  if( !verbose ){
    if( is.null(probs) ){
      result <- muhat
    }else{    
      result <- cbind(muhat,mMuQs)
      colnames(result)[1] <- "mu"
    }
  } #close if( !verbose )

  ##return everything:
  if( verbose ){
    result <- cbind(muhat)
    colnames(result) <- "mu"
    if( !is.null(mMuQs) ){ result <- cbind(result, mMuQs) }
#FOR THE FUTURE?:
#    if( !is.null(mYQs) ){ result <- cbind(result,mYQs) }
    if( !is.null(mMuHat) ){ result <- cbind(result, mMuHat) }
    if( !is.null(mY) ){ result <- cbind(result, mY) }
    if( !is.null(mZhat) ){ result <- cbind(result, mZhat) }
  } #close if( verbose )
    
  ##return the result:
  return(result)
  
} #close predict.lmem()  


###########################################################
## print.lmem() print the estimation result
###########################################################

print.lmem <- function(x, signif.stars=TRUE, verbose=FALSE, ...)
{
  ##obtain entry names:
  xNames <- names(x)

  ##-------------
  ## gets results
  ##-------------
  
  ##check if there is gets modelling:
  thereIsGetsModelling <- ifelse( "gum.call" %in% xNames, TRUE, FALSE)

  ##if gets modelling:
  if( verbose && thereIsGetsModelling ){

    ##print paths, terminals and retained regressors:
    if( !is.null(x$terminals.results) ){

      ##print gum results:
      if( !is.null(x$gum.results) ){
        cat("\n")
        cat("Start model:\n")
        cat("\n")
        printCoefmat(x$gum.results, cs.ind=c(1,2), tst.ind=c(3),
          signif.stars=TRUE, P.values=TRUE)
      }

      ##print gum diagnostics:
      if( !is.null(x$gum.diagnostics) ){
        cat("\n")
        cat("Diagnostics:\n")
        cat("\n")
        printCoefmat(x$gum.diagnostics, tst.ind=2, signif.stars=TRUE)
        cat("\n")
      }

      ##paths:
      if( length(x$paths)>0 ){
        cat("\n")
        cat("Paths searched:\n")
        cat("\n")
        for(i in 1:length(x$paths)){
          txt <- paste0(x$paths[[i]], collapse=" ")
          txt <- paste0("  Path ", i, ": ", txt)    
          cat(txt, "\n")
        }
      }
  
      ##print terminals:
      cat("\n")
      cat("Terminal models:\n")
      cat("\n")
      print(x$terminals.results)    
  
      ##retained regressors:
      cat("\n")
      cat("Retained regressors (final model):\n")
      if( length(x$specific.spec)==0 ){
        cat("  none\n")
      }else{
        cat(paste0(c("", names(x$specific.spec), "\n"), collapse="  "))
      }
      
    } #end if( print.searchinfo )
  
    ##messages:
    if(!is.null(x$messages)){
      message("\n", appendLF=FALSE)
      message("Messages:", appendLF=TRUE)
      message("\n", appendLF=FALSE)
      message(x$messages)
    }
        
  } #close if( verbose && thereIsGetsModelling )


  ##-------------------------
  ## estimation results
  ##-------------------------
  
  ##check if there are estimation results:
  thereAreResults <- ifelse("results" %in% xNames, TRUE, FALSE)

  ##header - first part:
  cat("\n")
  cat("Date:", x$date, "\n")
  cat("Dependent var.:", x$y.name, "\n")
  cat("Variance-Covariance:", switch(x$vcov.type, robust = "Robust (default)",
    "hac" = "HAC (Newey and West, 1987)"), "\n")
  cat("No. of observations:", x$n, "\n")

  ##header - sample info:
  if( "residuals" %in% xNames ){
    indexResiduals <- index(x$residuals)
    isRegular <- is.regular(x$residuals, strict=TRUE)
    isCyclical <- frequency(x$residuals) > 1
    if(isRegular && isCyclical){
      cycleResiduals <- cycle(x$residuals)
      startYear <- floor(as.numeric(indexResiduals[1]))
      startAsChar <- paste(startYear,
        "(", cycleResiduals[1], ")", sep="")
      endYear <- floor(as.numeric(indexResiduals[length(indexResiduals)]))
      endAsChar <- paste(endYear,
        "(", cycleResiduals[length(indexResiduals)], ")", sep="")
    }else{
      startAsChar <- as.character(indexResiduals[1])
      endAsChar <- as.character(indexResiduals[length(indexResiduals)])
    }
    cat("Sample:", startAsChar, "to", endAsChar, "\n")
  } #end if( "residuals" %in% xNames )

  ##print results:
  if( thereAreResults ){
    cat("\n")
    printCoefmat(x$results, signif.stars=signif.stars)
  }else{  
    cat("\n")
    cat("   No estimation results\n")
  }

  ##create goodness-of-fit matrix:
  gof <- matrix(NA, 1, 1)
  rownames(gof) <- paste0("Log-lik.(n=", x$n, "):")
  colnames(gof) <- ""
  gof[1,1] <- as.numeric(x$logl)

  ##print diagnostics and fit:
  if( !is.null(x$diagnostics) ) {
    cat("\n")
    cat("Diagnostics and fit:\n")
    cat("\n")
    printCoefmat(x$diagnostics, tst.ind=2,
      signif.stars=signif.stars, has.Pvalue=TRUE)
    printCoefmat(gof, digits=6, signif.stars=signif.stars)
  }

} #end print.lmem()


###########################################################
## residuals.lmem()
###########################################################

residuals.lmem <- function(object, ...){ return(object$residuals) }


###########################################################
## summary.lmem()
###########################################################

summary.lmem <- function(object, ...){ summary.default(object) }


###########################################################
## toLatex.lmem()
###########################################################

toLatex.lmem <- function(object, ...)
{
  printtex(object, fitted.name="\\ln y", ...)
}


###########################################################
## vcov.lmem()
###########################################################

vcov.lmem <- function(object, ...){ return(object$vcov) }
